import { API_CONFIG, LOG_LEVELS } from './Api_Config';

class Logger {
  constructor() {
    this.logs = [];
    this.maxLogs = 1000;
    this.enableFileLogging = API_CONFIG.LOG_TO_FILE;
    this.enableConsoleLogging = API_CONFIG.ENABLE_LOGGING;
  }

  // Log with level
  log(level, message, data = {}) {
    const logEntry = {
      timestamp: new Date().toISOString(),
      level,
      message,
      data,
      source: 'api',
    };

    // Add to memory
    this.logs.push(logEntry);
    
    // Keep only max logs
    if (this.logs.length > this.maxLogs) {
      this.logs.shift();
    }

    // Console output in development
    if (this.enableConsoleLogging) {
      const colors = {
        [LOG_LEVELS.ERROR]: '\x1b[31m', // Red
        [LOG_LEVELS.WARN]: '\x1b[33m',  // Yellow
        [LOG_LEVELS.INFO]: '\x1b[32m',  // Green
        [LOG_LEVELS.DEBUG]: '\x1b[36m', // Cyan
        [LOG_LEVELS.TRACE]: '\x1b[90m', // Gray
      };
      const reset = '\x1b[0m';
      
      console.log(
        `${colors[level] || ''}[${logEntry.timestamp}] ${level}: ${message}${reset}`,
        data
      );
    }

    // Save to file if enabled
    if (this.enableFileLogging) {
      this.saveToFile(logEntry);
    }

    // Store in window for debugging
    if (typeof window !== 'undefined') {
      window.__API_LOGS = window.__API_LOGS || [];
      window.__API_LOGS.push(logEntry);
      
      if (window.__API_LOGS.length > 100) {
        window.__API_LOGS.shift();
      }
    }

    return logEntry;
  }

  // Log levels
  error(message, data) {
    return this.log(LOG_LEVELS.ERROR, message, data);
  }

  warn(message, data) {
    return this.log(LOG_LEVELS.WARN, message, data);
  }

  info(message, data) {
    return this.log(LOG_LEVELS.INFO, message, data);
  }

  debug(message, data) {
    return this.log(LOG_LEVELS.DEBUG, message, data);
  }

  trace(message, data) {
    return this.log(LOG_LEVELS.TRACE, message, data);
  }

  // Request logging
  logRequest(request) {
    return this.info('API Request', {
      id: request.id,
      method: request.method,
      url: request.url,
      headers: request.headers,
      data: request.data,
      params: request.params,
    });
  }

  // Response logging
  logResponse(response) {
    return this.info('API Response', {
      id: response.id,
      status: response.status,
      duration: response.duration,
      data: response.data,
      headers: response.headers,
    });
  }

  // Error logging
  logError(error) {
    return this.error('API Error', {
      id: error.id,
      status: error.status,
      duration: error.duration,
      url: error.url,
      method: error.method,
      error: error.error,
      headers: error.headers,
    });
  }

  // Performance logging
  performance(metrics) {
    return this.debug('Performance', metrics);
  }

  // Save to file (client-side)
  saveToFile(logEntry) {
    try {
      // For client-side, we can use localStorage
      const logs = JSON.parse(localStorage.getItem(API_CONFIG.LOG_FILE_NAME) || '[]');
      logs.push(logEntry);
      
      // Keep only last 500 entries in localStorage
      if (logs.length > 500) {
        logs.shift();
      }
      
      localStorage.setItem(API_CONFIG.LOG_FILE_NAME, JSON.stringify(logs));
    } catch (error) {
      console.error('Failed to save log to file:', error);
    }
  }

  // Get logs from file
  getLogsFromFile() {
    try {
      return JSON.parse(localStorage.getItem(API_CONFIG.LOG_FILE_NAME) || '[]');
    } catch {
      return [];
    }
  }

  // Get all logs (memory + file)
  getAllLogs() {
    const fileLogs = this.getLogsFromFile();
    return [...fileLogs, ...this.logs];
  }

  // Clear logs
  clearLogs() {
    this.logs = [];
    localStorage.removeItem(API_CONFIG.LOG_FILE_NAME);
    if (window.__API_LOGS) {
      window.__API_LOGS = [];
    }
  }

  // Export logs
  exportLogs(format = 'json') {
    const logs = this.getAllLogs();
    
    if (format === 'json') {
      return JSON.stringify(logs, null, 2);
    } else if (format === 'csv') {
      const headers = ['timestamp', 'level', 'message', 'data'];
      const rows = logs.map(log => [
        log.timestamp,
        log.level,
        log.message,
        JSON.stringify(log.data)
      ]);
      return [headers, ...rows].map(row => row.join(',')).join('\n');
    }
    
    return logs;
  }

  // Download logs
  downloadLogs(filename = 'api_logs.json') {
    const data = this.exportLogs('json');
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }
}

export default new Logger();