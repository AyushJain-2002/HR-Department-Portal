import { API_CONFIG } from './Api_Config';

// Base URL with version
const BASE_URL = API_CONFIG.BASE_URL + API_CONFIG.API_VERSION;

// Endpoint Builder
const createEndpoint = (path) => `${BASE_URL}${path}`;

// Auth Endpoints
export const AUTH_ENDPOINTS = {
  LOGIN: createEndpoint('/Signin'),
  REGISTER: createEndpoint('/Signup'),
  LOGOUT: createEndpoint('/auth/logout'),
  REFRESH_TOKEN: createEndpoint('/auth/refresh'),
  FORGOT_PASSWORD: createEndpoint('/auth/forgot-password'),
  RESET_PASSWORD: createEndpoint('/auth/reset-password'),
  VERIFY_EMAIL: createEndpoint('/auth/verify-email'),
  VERIFY_OTP: createEndpoint('/auth/verify-otp'),
  CHANGE_PASSWORD: createEndpoint('/auth/change-password'),
  ME: createEndpoint('/auth/me'),
};

// User Endpoints
export const USER_ENDPOINTS = {
  GET_USERS: createEndpoint('/users'),
  GET_USER: (id) => createEndpoint(`/users/${id}`),
  CREATE_USER: createEndpoint('/users'),
  UPDATE_USER: (id) => createEndpoint(`/users/${id}`),
  DELETE_USER: (id) => createEndpoint(`/users/${id}`),
  UPDATE_PROFILE: createEndpoint('/users/profile'),
  UPLOAD_AVATAR: createEndpoint('/users/avatar'),
  GET_PREFERENCES: createEndpoint('/users/preferences'),
  UPDATE_PREFERENCES: createEndpoint('/users/preferences'),
  SEARCH_USERS: createEndpoint('/users/search'),
};

// Product Endpoints
export const PRODUCT_ENDPOINTS = {
  GET_PRODUCTS: createEndpoint('/products'),
  GET_PRODUCT: (id) => createEndpoint(`/products/${id}`),
  CREATE_PRODUCT: createEndpoint('/products'),
  UPDATE_PRODUCT: (id) => createEndpoint(`/products/${id}`),
  DELETE_PRODUCT: (id) => createEndpoint(`/products/${id}`),
  SEARCH_PRODUCTS: createEndpoint('/products/search'),
  GET_CATEGORIES: createEndpoint('/products/categories'),
  GET_BRANDS: createEndpoint('/products/brands'),
  UPLOAD_IMAGE: createEndpoint('/products/upload'),
  GET_REVIEWS: (id) => createEndpoint(`/products/${id}/reviews`),
  ADD_REVIEW: (id) => createEndpoint(`/products/${id}/reviews`),
};

// Order Endpoints
export const ORDER_ENDPOINTS = {
  GET_ORDERS: createEndpoint('/orders'),
  GET_ORDER: (id) => createEndpoint(`/orders/${id}`),
  CREATE_ORDER: createEndpoint('/orders'),
  UPDATE_ORDER: (id) => createEndpoint(`/orders/${id}`),
  CANCEL_ORDER: (id) => createEndpoint(`/orders/${id}/cancel`),
  GET_ORDER_HISTORY: createEndpoint('/orders/history'),
  GET_INVOICE: (id) => createEndpoint(`/orders/${id}/invoice`),
};

// Payment Endpoints
export const PAYMENT_ENDPOINTS = {
  CREATE_PAYMENT: createEndpoint('/payments/create'),
  CONFIRM_PAYMENT: createEndpoint('/payments/confirm'),
  GET_PAYMENT_METHODS: createEndpoint('/payments/methods'),
  ADD_PAYMENT_METHOD: createEndpoint('/payments/methods'),
  DELETE_PAYMENT_METHOD: (id) => createEndpoint(`/payments/methods/${id}`),
  GET_TRANSACTIONS: createEndpoint('/payments/transactions'),
};

// File Endpoints
export const FILE_ENDPOINTS = {
  UPLOAD: createEndpoint('/files/upload'),
  DELETE: (id) => createEndpoint(`/files/${id}`),
  DOWNLOAD: (id) => createEndpoint(`/files/${id}/download`),
  GET_FILES: createEndpoint('/files'),
};

// Notification Endpoints
export const NOTIFICATION_ENDPOINTS = {
  GET_NOTIFICATIONS: createEndpoint('/notifications'),
  MARK_AS_READ: (id) => createEndpoint(`/notifications/${id}/read`),
  MARK_ALL_READ: createEndpoint('/notifications/read-all'),
  DELETE_NOTIFICATION: (id) => createEndpoint(`/notifications/${id}`),
  GET_UNREAD_COUNT: createEndpoint('/notifications/unread-count'),
};

// Analytics Endpoints
export const ANALYTICS_ENDPOINTS = {
  GET_DASHBOARD: createEndpoint('/analytics/dashboard'),
  GET_REPORTS: createEndpoint('/analytics/reports'),
  GET_METRICS: createEndpoint('/analytics/metrics'),
  EXPORT_DATA: createEndpoint('/analytics/export'),
};

// Settings Endpoints
export const SETTINGS_ENDPOINTS = {
  GET_SETTINGS: createEndpoint('/settings'),
  UPDATE_SETTINGS: createEndpoint('/settings'),
  GET_LOGS: createEndpoint('/settings/logs'),
  CLEAR_LOGS: createEndpoint('/settings/logs/clear'),
};

// Export all endpoints
export default {
  AUTH: AUTH_ENDPOINTS,
  USER: USER_ENDPOINTS,
  PRODUCT: PRODUCT_ENDPOINTS,
  ORDER: ORDER_ENDPOINTS,
  PAYMENT: PAYMENT_ENDPOINTS,
  FILE: FILE_ENDPOINTS,
  NOTIFICATION: NOTIFICATION_ENDPOINTS,
  ANALYTICS: ANALYTICS_ENDPOINTS,
  SETTINGS: SETTINGS_ENDPOINTS,
};