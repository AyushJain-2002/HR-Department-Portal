import axios from 'axios';
import { API_CONFIG, TOKEN_CONFIG } from './Api_Config';
import logger from './Logger';
import endpoints from './Endoints';

class TokenManager {
  constructor() {
    this.storage = TOKEN_CONFIG.STORAGE_TYPE === 'localStorage' 
      ? localStorage 
      : sessionStorage;
  }

  // Get access token
  getAccessToken() {
    try {
      return this.storage.getItem(TOKEN_CONFIG.ACCESS_TOKEN_KEY);
    } catch (error) {
      logger.error('Failed to get access token:', error);
      return null;
    }
  }

  // Get refresh token
  getRefreshToken() {
    try {
      return this.storage.getItem(TOKEN_CONFIG.REFRESH_TOKEN_KEY);
    } catch (error) {
      logger.error('Failed to get refresh token:', error);
      return null;
    }
  }

  // Set tokens
  setTokens(accessToken, refreshToken) {
    try {
      this.storage.setItem(TOKEN_CONFIG.ACCESS_TOKEN_KEY, accessToken);
      if (refreshToken) {
        this.storage.setItem(TOKEN_CONFIG.REFRESH_TOKEN_KEY, refreshToken);
      }
      logger.info('Tokens stored successfully');
    } catch (error) {
      logger.error('Failed to store tokens:', error);
    }
  }

  // Clear all tokens
  clearTokens() {
    try {
      this.storage.removeItem(TOKEN_CONFIG.ACCESS_TOKEN_KEY);
      this.storage.removeItem(TOKEN_CONFIG.REFRESH_TOKEN_KEY);
      this.storage.removeItem('user_data');
      logger.info('Tokens cleared');
    } catch (error) {
      logger.error('Failed to clear tokens:', error);
    }
  }

  // Check if token is expired
  isTokenExpired(token) {
    if (!token) return true;
    
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      const expiryTime = payload.exp * 1000;
      const currentTime = Date.now();
      const buffer = TOKEN_CONFIG.TOKEN_EXPIRY_BUFFER;
      
      return expiryTime - buffer < currentTime;
    } catch (error) {
      logger.error('Token parsing failed:', error);
      return true;
    }
  }

  // Decode token payload
  decodeToken(token) {
    if (!token) return null;
    
    try {
      const payload = token.split('.')[1];
      return JSON.parse(atob(payload));
    } catch (error) {
      logger.error('Failed to decode token:', error);
      return null;
    }
  }

  // Get user info from token
  getUserFromToken() {
    const token = this.getAccessToken();
    if (!token) return null;
    
    const decoded = this.decodeToken(token);
    if (!decoded) return null;
    
    return {
      id: decoded.sub || decoded.userId,
      email: decoded.email,
      username: decoded.username,
      role: decoded.role,
      permissions: decoded.permissions || [],
      exp: decoded.exp,
      iat: decoded.iat,
    };
  }

  // Refresh token
  async refreshToken() {
    const refreshToken = this.getRefreshToken();
    
    if (!refreshToken) {
      logger.warn('No refresh token available');
      return null;
    }
    
    try {
      const response = await axios.post(endpoints.AUTH.REFRESH_TOKEN, {
        refreshToken,
      });
      
      const { accessToken, refreshToken: newRefreshToken } = response.data;
      
      this.setTokens(accessToken, newRefreshToken);
      logger.info('Token refreshed successfully');
      
      return accessToken;
    } catch (error) {
      logger.error('Token refresh failed:', error);
      this.clearTokens();
      throw error;
    }
  }

  // Save user data
  saveUserData(userData) {
    try {
      this.storage.setItem('user_data', JSON.stringify(userData));
    } catch (error) {
      logger.error('Failed to save user data:', error);
    }
  }

  // Get user data
  getUserData() {
    try {
      const data = this.storage.getItem('user_data');
      return data ? JSON.parse(data) : null;
    } catch (error) {
      logger.error('Failed to get user data:', error);
      return null;
    }
  }

  // Clear user data
  clearUserData() {
    try {
      this.storage.removeItem('user_data');
    } catch (error) {
      logger.error('Failed to clear user data:', error);
    }
  }
}

export default new TokenManager();