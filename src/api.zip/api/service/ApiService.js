import axiosInstance from '../axiosInstance';
import logger from '../Logger';
import errorHandler from '../ErrorHandler';
import { API_CONFIG } from '../Api_Config';

class ApiService {
  constructor() {
    this.cache = new Map();
  }

  // Generic request method
  async request(config) {
    const cacheKey = config.cacheKey || this.generateCacheKey(config);
    
    // Check cache
    if (config.cache && this.cache.has(cacheKey)) {
      const cached = this.cache.get(cacheKey);
      if (Date.now() - cached.timestamp < API_CONFIG.CACHE_DURATION) {
        logger.debug('Cache hit', { key: cacheKey });
        return cached.data;
      }
      this.cache.delete(cacheKey);
    }
    
    try {
      const response = await axiosInstance(config);
      
      // Cache response if enabled
      if (config.cache) {
        this.cache.set(cacheKey, {
          data: response.data,
          timestamp: Date.now(),
        });
      }
      
      return response.data;
    } catch (error) {
      throw errorHandler.handleApiError(error, { config });
    }
  }

  // HTTP methods
  get(url, config = {}) {
    return this.request({
      method: 'GET',
      url,
      ...config,
    });
  }

  post(url, data, config = {}) {
    return this.request({
      method: 'POST',
      url,
      data,
      ...config,
    });
  }

  put(url, data, config = {}) {
    return this.request({
      method: 'PUT',
      url,
      data,
      ...config,
    });
  }

  patch(url, data, config = {}) {
    return this.request({
      method: 'PATCH',
      url,
      data,
      ...config,
    });
  }

  delete(url, config = {}) {
    return this.request({
      method: 'DELETE',
      url,
      ...config,
    });
  }

  // Upload file
  upload(url, file, onProgress, config = {}) {
    const formData = new FormData();
    formData.append('file', file);
    
    return this.request({
      method: 'POST',
      url,
      data: formData,
      headers: {
        'Content-Type': 'multipart/form-data',
      },
      onUploadProgress: onProgress,
      timeout: API_CONFIG.UPLOAD_TIMEOUT,
      ...config,
    });
  }

  // Batch requests
  async batch(requests, config = {}) {
    return Promise.allSettled(
      requests.map(req => this.request({ ...req, ...config }))
    );
  }

  // Clear cache
  clearCache(key) {
    if (key) {
      this.cache.delete(key);
    } else {
      this.cache.clear();
    }
  }

  // Generate cache key
  generateCacheKey(config) {
    return `${config.method}_${config.url}_${JSON.stringify(config.params || {})}_${JSON.stringify(config.data || {})}`;
  }

  // Cancel token
  createCancelToken() {
    return axios.CancelToken.source();
  }
}

export default new ApiService();