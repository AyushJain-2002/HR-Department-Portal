import apiService from './ApiService';
import endpoints from '../Endpoints';
import tokenManager from '../TokenManager';

class AuthService {
  // Login
  async login(credentials) {
    const response = await apiService.post(endpoints.AUTH.LOGIN, credentials);
    
    if (response.tokens) {
      tokenManager.setTokens(
        response.tokens.accessToken,
        response.tokens.refreshToken
      );
      
      if (response.user) {
        tokenManager.saveUserData(response.user);
      }
    }
    
    return response;
  }

  // Register
  async register(userData) {
    return apiService.post(endpoints.AUTH.REGISTER, userData);
  }

  // Logout
  async logout() {
    try {
      await apiService.post(endpoints.AUTH.LOGOUT);
    } finally {
      tokenManager.clearTokens();
      tokenManager.clearUserData();
    }
  }

  // Get current user
  async getCurrentUser() {
    const cachedUser = tokenManager.getUserData();
    if (cachedUser) {
      return cachedUser;
    }
    
    const response = await apiService.get(endpoints.AUTH.ME);
    tokenManager.saveUserData(response.user);
    return response.user;
  }

  // Forgot password
  async forgotPassword(email) {
    return apiService.post(endpoints.AUTH.FORGOT_PASSWORD, { email });
  }

  // Reset password
  async resetPassword(token, newPassword) {
    return apiService.post(endpoints.AUTH.RESET_PASSWORD, {
      token,
      password: newPassword,
    });
  }

  // Change password
  async changePassword(currentPassword, newPassword) {
    return apiService.post(endpoints.AUTH.CHANGE_PASSWORD, {
      currentPassword,
      newPassword,
    });
  }

  // Verify email
  async verifyEmail(token) {
    return apiService.post(endpoints.AUTH.VERIFY_EMAIL, { token });
  }

  // Check if user is authenticated
  isAuthenticated() {
    const token = tokenManager.getAccessToken();
    return token && !tokenManager.isTokenExpired(token);
  }

  // Get user from token
  getUserFromToken() {
    return tokenManager.getUserFromToken();
  }
}

export default new AuthService();