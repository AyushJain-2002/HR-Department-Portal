import logger from '../api/Logger';

// Debug panel component
export const DebugPanel = () => {
  const toggleDebug = () => {
    const debugDiv = document.getElementById('api-debug-panel');
    if (debugDiv) {
      debugDiv.style.display = debugDiv.style.display === 'none' ? 'block' : 'none';
    }
  };
  
  const clearLogs = () => {
    logger.clearLogs();
    console.clear();
    alert('Logs cleared');
  };
  
  const exportLogs = () => {
    logger.downloadLogs();
  };
  
  const showLogs = () => {
    const logs = logger.getAllLogs();
    console.table(logs.map(log => ({
      timestamp: log.timestamp,
      level: log.level,
      message: log.message,
    })));
  };
  
  // Create debug panel
  if (process.env.NODE_ENV === 'development') {
    setTimeout(() => {
      if (!document.getElementById('api-debug-panel')) {
        const panel = document.createElement('div');
        panel.id = 'api-debug-panel';
        panel.style.cssText = `
          position: fixed;
          bottom: 10px;
          right: 10px;
          background: #333;
          color: white;
          padding: 10px;
          border-radius: 5px;
          z-index: 9999;
          font-family: monospace;
          font-size: 12px;
        `;
        
        panel.innerHTML = `
          <h4 style="margin: 0 0 10px 0;">API Debug</h4>
          <button onclick="window.__DEBUG.toggle()" style="margin: 2px;">Toggle</button>
          <button onclick="window.__DEBUG.showLogs()" style="margin: 2px;">Show Logs</button>
          <button onclick="window.__DEBUG.clearLogs()" style="margin: 2px;">Clear</button>
          <button onclick="window.__DEBUG.exportLogs()" style="margin: 2px;">Export</button>
        `;
        
        document.body.appendChild(panel);
        
        // Add to window for global access
        window.__DEBUG = {
          toggle: toggleDebug,
          showLogs,
          clearLogs,
          exportLogs,
          logger,
        };
      }
    }, 1000);
  }
};

// Performance monitoring
export const monitorPerformance = () => {
  if (typeof window !== 'undefined' && 'performance' in window) {
    const performanceEntries = performance.getEntriesByType('navigation');
    if (performanceEntries.length > 0) {
      const navEntry = performanceEntries[0];
      logger.performance({
        type: 'page_load',
        dns: navEntry.domainLookupEnd - navEntry.domainLookupStart,
        tcp: navEntry.connectEnd - navEntry.connectStart,
        request: navEntry.responseStart - navEntry.requestStart,
        response: navEntry.responseEnd - navEntry.responseStart,
        domLoaded: navEntry.domContentLoadedEventEnd - navEntry.domContentLoadedEventStart,
        load: navEntry.loadEventEnd - navEntry.loadEventStart,
      });
    }
  }
};

// Error boundary catcher
export const catchErrors = (error, errorInfo) => {
  logger.error('React Error Boundary', {
    error: error.toString(),
    stack: error.stack,
    componentStack: errorInfo?.componentStack,
  });
};

export default {
  DebugPanel,
  monitorPerformance,
  catchErrors,
};